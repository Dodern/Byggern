#include <avr/io.h>
#include <stdbool.h>

#include "adc_driver.h"
#include "xmem.h"
#include "uart.h"
#include "bit_macros.h"

static uint8_t read_data_array[4];
static uint8_t joystick_center_array[2];
static int8_t joystick_current_position[2];


const char* adc_channels[] = {
    "JOYSTICK_VERTICAL" ,
    "JOYSTICK_HORIZONTAL",
    "LEFT_SLIDER",
    "RIGHT_SLIDER"
};



void adc_init(){
    adc_read_all_channels();
    joystick_center_array[0] = read_data_array[1];
    joystick_center_array[1] = read_data_array[0];
    PORTB &=  ~(1 << PB0) | ~(1 << PB1); // Setting to input for buttons
    DDRB &=  ~(1 << DDB0) | ~(1 << DDB1); // Setting to input for buttons
}

void adc_select_channel(uint8_t channel){
  xmem_write(channel, 0, ADC);
  _delay_ms(40);
}

void adc_read_all_channels(){
  for (uint8_t i = 0; i < 4; i++) {
    adc_select_channel(i+4);
    read_data_array[i] = xmem_read(0,ADC);
    _delay_ms(40);
  }
}

int joystick_percent_formula(int read_index, uint8_t center_value){
  int data =(read_data_array[read_index]-center_value)/(255.0-center_value)*100;
  printf("data: %d\n\r", data);
  return data;
}

void adc_read_joystick_position(){
  adc_read_all_channels();
  uint8_t x_mid = joystick_center_array[0];
  uint8_t y_mid = joystick_center_array[1];
  joystick_current_position[0] = (read_data_array[1]-x_mid)/(255.0-x_mid)*100;
  joystick_current_position[1] = (read_data_array[0]-y_mid)/(255.0-y_mid)*100;
}



// **** Get and Update Functions **** //

uint8_t adc_get_joystick_direction(){
    adc_read_joystick_position();
    uint8_t vertical_value = read_data_array[0];
    uint8_t horizontal_value = read_data_array[1];
    enum joystick_direction dir = 0;

    if (horizontal_value > 200) {
        dir = RIGHT;
    }
    else if  (horizontal_value < 70) {
        dir = LEFT;
    }
    else if (vertical_value > 200) {
        dir = UP;
    }
    else if (vertical_value < 70) {
        dir = DOWN;
    } else{
        dir = NEUTRAL;
    }
    return dir;
}

void adc_get_joystick_position(uint8_t* arr){
  adc_read_all_channels();
  arr[0] = read_data_array[1];
  arr[1] = read_data_array[0];
  printf("X-arr: %d, Y-arr: %d \n\r", arr[0], arr[1]);
}

void adc_get_joystick_percent_position(uint8_t* arr){
  adc_read_joystick_position();
  arr[0] = joystick_current_position[0];
  arr[1] = joystick_current_position[1];
  printf("X-arr: %d, Y-arr: %d \n\r", arr[0], arr[1]);
}

uint8_t adc_get_right_slider_position(void){
  adc_read_all_channels();
  return read_data_array[3];
}

uint8_t adc_get_left_slider_position(void){
  adc_read_all_channels();
  return read_data_array[3];
}

void adc_update_all_player_inputs(uint8_t *player_inputs){
  adc_read_all_channels();
  player_inputs[0] = read_data_array[0]; // JOYSTICK_VERTICAL
  player_inputs[1] = read_data_array[1]; // "JOYSTICK_HORIZONTAL"
  player_inputs[2] = read_data_array[2]; // "LEFT_SLIDER",
  player_inputs[3] = read_data_array[3]; // "RIGHT_SLIDER"
  player_inputs[4] = adc_is_joystick_button_pressed();
  player_inputs[5] = adc_is_left_button_pressed();
  player_inputs[6] = adc_is_right_button_pressed();
}




// **** Button Functions **** //


int adc_is_joystick_button_pressed(){
	if (read_bit(PINB, PINB0) == 0) {
		return true;
	} else {
		return false;
	}
}

int adc_is_left_button_pressed(){
	if (read_bit(PINB, PINB1) == 0) {
		return false;
	} else {
		return true;
	}
}

int adc_is_right_button_pressed(){
	if (read_bit(PINB, PINB2) == 0) {
		return false;
	} else {
		return true;
	}
}




// **** Print Functions **** //

void adc_print_all_channels(){
  adc_read_all_channels();
  for (uint8_t i=0; i < 4; i++) {
    printf(" %s: %d ", adc_channels[i], read_data_array[i] );
  }
  printf("\n\r");
}

void adc_print_current_position(){
  adc_read_joystick_position();
  printf("X: %d, Y: %d \n\r", joystick_current_position[0], joystick_current_position[1]);
}

void adc_print_direction(uint8_t direction){
  enum joystick_direction dir = 0;
  printf("Direction: ");
  switch (direction){

  case RIGHT:
    printf("Right");
    break;
  case LEFT:
    printf("Left");
    break;
  case UP:
    printf("Up");
    break;
  case DOWN:
    printf("Down");
    break;
  case NEUTRAL:
    printf("Neutral");
    break;
  default:
    break;
  }
  printf("\n\r");
}

int adc_print_button_states(){
	int joy_btn = adc_is_joystick_button_pressed();
	int left_btn = adc_is_left_button_pressed();
	int right_btn = adc_is_right_button_pressed();
	printf("Current button states - Joystick: %d  LeftButton: %d  RightButton: %d\n\r", joy_btn, left_btn, right_btn);
}
