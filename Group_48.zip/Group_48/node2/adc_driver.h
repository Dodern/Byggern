#ifndef ADC_DRIVER_H
#define ADC_DRIVER_H

void adc_init();
int adc_read();
void adc_print();

#endif