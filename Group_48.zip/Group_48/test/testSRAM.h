#ifndef TESTSRAM_H 
#define TESTSRAM_H  

#include "uart.h"
#include <stdlib.h>

void SRAM_test(void);
void SRAM_test_can(void);

#endif